# bunny-cdn-python 
Bunny CDN is the fastest and Cheapest CDN

This is a bunny cdn python module for buny cdn API 

# How to Use IT
As of now there are 4 commands whch are listed below with their patrameters
1.create_pull_zone(api, name, original_url, type)
2.delete_pull_zone(api, id)
3.purge_cache(api, id)
4.add_host_name(api, id, Hostname)

# INFO
1. This is not a official bunny cdn module


